package Radio_Londres;

public class Controler_RadioLondres {
    private RadioLondres radioLondres;

    public Controler_RadioLondres(RadioLondres radioLondres) {
        this.radioLondres = radioLondres;
    }

    public void diffuseMessage(){
        this.radioLondres.diffuseMessage();
    }

    public RadioLondres getRadioLondres() {
        return radioLondres;
    }
}
