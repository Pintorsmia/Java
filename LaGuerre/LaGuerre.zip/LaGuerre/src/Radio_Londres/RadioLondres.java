package Radio_Londres;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observable;

public class RadioLondres extends Observable {
    private ArrayList<Resistant> lesResistants = new ArrayList<Resistant>();
    private ArrayList<String> listeMessages = new ArrayList<String>();
    private String leMessageDiffuse;
    private String nomRadio;
    private Iterator itMessage;

    public RadioLondres(String nom) {
        this.nomRadio = nom;
    }

    public void addResistant(Resistant resistantPersonne) {
        this.lesResistants.add(resistantPersonne);
        this.listeMessages.addAll(resistantPersonne.getLesMessages());
        //maj de l'iterateur
        itMessage = listeMessages.iterator();
    }

    public void diffuseMessage() {
        if(itMessage.hasNext()) {
            this.leMessageDiffuse = this.itMessage.next().toString();
        }
        setChanged();
        notifyObservers();
    }

    public ArrayList<Resistant> getLesResistants() {
        return lesResistants;

    }

    public String getLeMessageDiffuse() {
        return leMessageDiffuse;
    }
}


