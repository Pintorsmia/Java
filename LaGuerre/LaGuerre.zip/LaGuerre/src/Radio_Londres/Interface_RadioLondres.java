package Radio_Londres;

import java.util.Observable;
import java.util.Observer;

public class Interface_RadioLondres implements Observer {
    private Controler_RadioLondres ControllerRadio;

    public Interface_RadioLondres(Controler_RadioLondres controllerRadio) {
        ControllerRadio = controllerRadio;
        ControllerRadio.getRadioLondres().addObserver(this);
    }

    @Override
    public void update(Observable observable, Object o) {
        System.out.println(ControllerRadio.getRadioLondres().getLeMessageDiffuse());
    }
}
