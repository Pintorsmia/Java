package Radio_Londres;

import java.util.ArrayList;

public class TestMain {
    public static void main(String[] args) {

        //Initialisation des objets
        FlotteAlliee Allie1 = new FlotteAlliee("Les_Allies");
        ArrayList<String> ArrayMessages = new ArrayList<String>();
        ArrayMessages.add("Test");
        ArrayMessages.add("Aled");
        ArrayMessages.add("pouet");
        Resistant Resistant1 = new Resistant("Resistant1",ArrayMessages,Allie1);
        RadioLondres Radio = new RadioLondres("Radio");

        //add des resistant pour la radio
        Radio.addResistant(Resistant1);

        //Initialisation controller
        Controler_RadioLondres controler_radioLondres = new Controler_RadioLondres(Radio);

        //Initialisation Vue
        Interface_RadioLondres interface_Radio = new Interface_RadioLondres(controler_radioLondres);

        //Test
        //System.out.println(Resistant1.getPseudo() + " et " + Resistant1.getLesMessages());

        //Correspond au bouton message suivant
        controler_radioLondres.diffuseMessage();
        controler_radioLondres.diffuseMessage();
    }
}