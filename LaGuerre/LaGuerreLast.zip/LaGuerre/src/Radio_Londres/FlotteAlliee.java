package Radio_Londres;

public class FlotteAlliee {
    private String pseudo;

    public FlotteAlliee(String pseudo) {
        this.pseudo = pseudo;
    }

    public String getPseudo() {
        return pseudo;
    }
}
