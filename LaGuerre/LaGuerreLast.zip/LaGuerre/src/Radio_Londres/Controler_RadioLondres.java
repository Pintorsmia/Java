package Radio_Londres;

import java.util.ArrayList;

public class Controler_RadioLondres {
    private RadioLondres radioLondres;

    public Controler_RadioLondres(RadioLondres radioLondres) {
        this.radioLondres = radioLondres;
    }

    public ArrayList<Resistant> getResistantControler(){
        return this.radioLondres.getResistants();
    }

    public void addResistantControler(Resistant resistant){
        this.radioLondres.addResistantDiffuseurs(resistant);
    }

    public void diffuseMessageControler(){
        this.radioLondres.diffuseMessage();
    }

    public RadioLondres getRadioLondres() {
        return radioLondres;
    }
}
