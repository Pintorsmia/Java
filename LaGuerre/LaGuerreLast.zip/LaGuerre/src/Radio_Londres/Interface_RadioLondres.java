package Radio_Londres;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

public class Interface_RadioLondres extends JFrame implements Observer {
    private Controler_RadioLondres controler_radioLondres;
    private JPanel container;
    private JList listeResistants;
    private JButton nextMessageButton;
    private JLabel diffuseMessageLabel;
    private String messageLabel;

    public Interface_RadioLondres(Controler_RadioLondres controllerRadio) {
        super();
        this.controler_radioLondres = controllerRadio;
        this.controler_radioLondres.getRadioLondres().addObserver(this);

        this.container = new JPanel();
        //Creation de l'interface
        setTitle("Ma fenetre");
        setSize(600,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String test[]= {"1","2","47"};
        //Creation des objet dans notre fenetre
        //Creation de la liste
        this.listeResistants = new JList(test);
        //Creation du bouton
        this.nextMessageButton = new JButton("Message Suivant");
        //Pour afficher du texte
        this.diffuseMessageLabel = new JLabel();
        //False car pour le moment il n'y a pas de texte a afficher
        //this.diffuseMessageLabel.setVisible(false);

        //ajout des elements dans le container
        container.add(listeResistants);
        container.add(nextMessageButton);
        container.add(diffuseMessageLabel);
        //Creation de notre container
        setContentPane(container);

        //Affiche la fenetre
        setVisible(true);
        //Met à jour des information (pas très utile dans notre cas, mais on sait jamais)
        repaint();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        this.diffuseMessageLabel.setText(this.messageLabel);
        this.diffuseMessageLabel.setVisible(true);
    }

    @Override
    public void update(Observable observable, Object o) {
       // System.out.println(controler_radioLondres.getRadioLondres().getLeMessageDiffuse());
        this.messageLabel = controler_radioLondres.getRadioLondres().getMessageDiffuse();
        repaint();
    }


    public void ajouterEvent() {
        //ajoute une action au bouton
        this.nextMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                //le try and catch ne dois pas être obligatoire mais c est dans le cour
                try {
                    //fait appel a une fonction du controleur qui lui meme fait appel a une fonction du model
                    // pour passer au message suivant
                    //controler_radioLondres.diffuseMessage();
                    controler_radioLondres.diffuseMessageControler();
                } catch (Exception err) {
                    System.err.println("Erreur" + err.toString());
                    err.printStackTrace();
                }
            }
        });
    }
}
