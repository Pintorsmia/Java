package Radio_Londres;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Observable;

public class RadioLondres extends Observable {
    private ArrayList<Resistant> lesResistants;
    private ArrayList<String> listeMessages;
    private Iterator itMessage;
    private String leMessageDiffuse;
    private String nomRadio;

    public RadioLondres(String nom) {
        this.nomRadio = nom;
        this.lesResistants = new ArrayList<Resistant>();
        this.listeMessages = new ArrayList<String>();
        this.itMessage = listeMessages.iterator();
    }

    public void addResistant(Resistant resistantPersonne) {
        this.lesResistants.add(resistantPersonne);
    }

    public void messageSuivant(){
        if(itMessage.hasNext()) {
            this.leMessageDiffuse = (String) this.itMessage.next();
        }else{
            this.leMessageDiffuse = "Fin";
        }
    }
    public void addResistantDiffuseurs(Resistant resistantPersonne){
        this.listeMessages.addAll(resistantPersonne.getLesMessages());
        //maj de l'iterateur
        itMessage = listeMessages.iterator();
    }

    public void diffuseMessage() {
        messageSuivant();
        setChanged();
        notifyObservers();
    }


    public ArrayList<Resistant> getResistants() {
        return lesResistants;
    }

    public String getMessageDiffuse() {
        return leMessageDiffuse;
    }
}


